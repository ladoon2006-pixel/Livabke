import { supabaseClient as supabase } from "./supabase/client.js";

let me = null;
let currentRoom = null;
let sub = null;

// تغییر صفحه
function show(page) {
  document.querySelectorAll(".page").forEach(p => p.classList.remove("active"));
  document.getElementById(page).classList.add("active");
}

// ذخیره نام کاربری و ساخت پروفایل
window.saveUsername = async function () {
  const name = document.getElementById("username").value.trim();
  if (!name) {
    alert("نام کاربری وارد کن");
    return;
  }

  const { data, error } = await supabase
    .from("profiles")
    .insert({ nickname: name, is_online: true })
    .select()
    .single();

  if (error) {
    console.log(error);
    alert("خطا در ذخیره نام کاربری");
    return;
  }

  me = data;
  localStorage.setItem("user", JSON.stringify(me));

  document.getElementById("welcome").innerText = "سلام " + name + " 👋";

  show("home-page");
};

// شروع چت تصادفی
window.startChat = async function () {
  if (!me) {
    const saved = localStorage.getItem("user");
    if (saved) me = JSON.parse(saved);
    else return alert("اول وارد شو");
  }

  const { data: users, error } = await supabase
    .from("profiles")
    .select("id")
    .eq("is_online", true)
    .neq("id", me.id);

  if (error) {
    console.log(error);
    alert("خطا در دریافت کاربران آنلاین");
    return;
  }

  if (!users || users.length === 0) {
    alert("فعلاً کسی آنلاین نیست");
    return;
  }

  const partner = users[Math.floor(Math.random() * users.length)].id;

  const { data: room, error: roomErr } = await supabase
    .from("rooms")
    .insert({ user1: me.id, user2: partner })
    .select()
    .single();

  if (roomErr) {
    console.log(roomErr);
    alert("خطا در ساخت اتاق چت");
    return;
  }

  currentRoom = room;

  listen(room.id);

  show("chat-page");
};

// گوش دادن به پیام‌ها
function listen(roomId) {
  sub = supabase
    .channel("room-" + roomId)
    .on(
      "postgres_changes",
      {
        event: "INSERT",
        schema: "public",
        table: "messages",
        filter: "room_id=eq." + roomId
      },
      (payload) => {
        const msg = payload.new;
        const box = document.getElementById("chat-box");
        box.innerHTML += `<div class="msg">${msg.content}</div>`;
        box.scrollTop = box.scrollHeight;
      }
    )
    .subscribe();
}

// ارسال پیام
window.sendMsg = async function () {
  if (!currentRoom || !me) return;

  const text = document.getElementById("msg").value.trim();
  if (!text) return;

  const { error } = await supabase.from("messages").insert({
    room_id: currentRoom.id,
    sender_id: me.id,
    content: text
  });

  if (error) {
    console.log(error);
    alert("خطا در ارسال پیام");
    return;
  }

  document.getElementById("msg").value = "";
};
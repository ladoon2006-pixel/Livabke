const { createClient } = supabase;

export const supabaseClient = createClient(
  "https://scwihqxfzzwdxdpwzswv.supabase.co",
  "sb_publishable_zzICxS7wVCiPh1SQWpsO9A_ZKQpSe1z"
);